// Assignment 1 | COMP1073 Client-Side JavaScript

/* Variables
-------------------------------------------------- */
// Create a new speechSynthesis object
var synth = window.speechSynthesis;
// Learn more about SpeechSynthesis.speak() at https://developer.mozilla.org/en-US/docs/Web/API/SpeechSynthesis/speak
var msg1 = ['The turkey','mom','dad','The Dog','My Teacher', 'The elephant'];
var speak1 = document.querySelector("#btn1");

var msg2 = ['Sat on', 'ate','danced with','saw',"Doesn't like", 'kissed'];
var speak2 = document.querySelector("#btn2");

var msg3 = ['a funny', 'a scary','a goofy','a slimy','a barking', 'a fat'];
var speak3 = document.querySelector("#btn3");

var msg4 = ['Goat', 'Monkey','Fish','Cow','Frog', 'Bug'];
var speak4 = document.querySelector("#btn4");

var msg5 = ['Oakville', 'Scarborough', 'Burlington', 'Vaughan', 'Markham', 'Yorkville'];
var speak5 = document.querySelector("#btn5");

var msg6 = msg1[Math.floor(Math.random() *msg1.length)] + msg2[Math.floor(Math.random() *msg2.length)] +msg3[Math.floor(Math.random() *msg3.length)] + msg4[Math.floor(Math.random() *msg4.length)] + msg5[Math.floor(Math.random() *msg5.length)];
var speak6 = document.querySelector("#btn6");


/* Functions
-------------------------------------------------- */
function speakNow(string) {
	// Create a new speech object, attaching the string of text to speak
	var utterThis = new SpeechSynthesisUtterance(string);
	// Actually speak the text
	synth.speak(utterThis);
}

/* Event Listeners
-------------------------------------------------- */
// Onclick handler for the button that speaks the text contained in the above var textToSpeak

speak1.onclick = function() {
	speakNow(msg1);
}
speak2.onclick = function() {
	speakNow(msg2);
}
speak3.onclick = function() {
	speakNow(msg3);
}
speak4.onclick = function() {
	speakNow(msg4);
}
speak5.onclick = function() {
	speakNow(msg5);
}
speak6.onclick = function() {
	speakNow(msg6);
}




